public class Vehicle
{
    public int price;
    public string brand;
    public string color;

    public Vehicle(int price,string brand, string color)
    {
        this.price = price;
        this.brand = brand;
        this.color = color;
    }
    
    public void display()
    {
        Console.WriteLine(this.price);
        Console.WriteLine(this.brand);
        Console.WriteLine(this.color);
    }

}

public class MyClass
{
    public static void Main(string[] args)
    {
        Vehicle omni = new Vehicle(10000,"Maruti","Red");
       omni.display();

    }
}