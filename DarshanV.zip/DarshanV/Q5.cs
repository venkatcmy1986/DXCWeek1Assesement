public class Myclass
{
    public static void Main()
    {


        Stack<int> myStack1 = new Stack<int>();
        Stack<int> myStack2 = new Stack<int>();
        Console.WriteLine("enter number of elements in stack");
        int n = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("enter the elements");
        for (int i = 0; i < n; i++)
        {

            myStack1.Push(Convert.ToInt32(Console.ReadLine()));
        }


        Console.WriteLine("elements in stack are");
        foreach (var item in myStack1)
            Console.Write(item + ",");
        Console.WriteLine("enter element to be removed");
        int c = Convert.ToInt32(Console.ReadLine());

        for (int i = 0; i < myStack1.Count(); i++)
        {
            if (myStack1.Peek() == c)
                continue;
            else
                myStack2.Push(myStack1.Pop());
        }
        Console.WriteLine("elements in stack after removing are");
        foreach (var item in myStack2)
            Console.Write(item + ",");

    }
}