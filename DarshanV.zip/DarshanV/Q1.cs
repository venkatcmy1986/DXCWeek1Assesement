public class Program
{
    public static void Main(string[] args)
    {
        int ip = Convert.ToInt32(Console.ReadLine());

        for (int i = 0; i < ip; i++)
        {
            for (int j = 0; j < i; j++)
            {
                Console.Write(j);
            }
            Console.WriteLine();
        }
    }
}