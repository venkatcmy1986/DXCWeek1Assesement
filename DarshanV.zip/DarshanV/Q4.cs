public class MyClass
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter a number");
        int fibnum = Convert.ToInt32(Console.ReadLine());
        int fibarr = fibnum * (fibnum + 1) / 2;
        int [] a = new int[fibarr+1];


        a[1] = 1;
        a[2] = 2;
        for (int i = 3; i < fibarr; i++)
        {
            a[i] = a[i - 1] + a[i - 2];
            //Console.WriteLine(a[i]);
        }


        int iter = 1;
        for(int i = 1; i <= fibnum; i++)
        {
            for(int j = 1; j <= i; j++)
            {
                Console.Write(a[iter++]+" ");
            }
            Console.WriteLine();
        }

    }

    
}