public class MyClass
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter candidates Math marks");
        int maths = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter candidates Physics marks");
        int phy = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter candidates Chemistry marks");
        int chem = Convert.ToInt32(Console.ReadLine());

        if((maths >= 65 && phy >= 55 && chem >= 50) && (maths + phy+ chem) >=180)
        {
            Console.WriteLine("The candidate is Eligible");
        }
        else if (maths + phy >= 140)
        {
            Console.WriteLine("The candidate is available based on Maths and Physics Marks");
        }
        else
        {
            Console.WriteLine("The candidate is not eligible");
        }

    }
}