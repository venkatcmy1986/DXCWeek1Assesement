public class MyClass
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter Size of Arrays");
        int size = Convert.ToInt32(Console.ReadLine());
        int[] arr = new int[size];
        Console.WriteLine("Enter elements of array 1");
        for (int i = 0; i < size; i++)
        {
            arr[i]=Convert.ToInt32(Console.ReadLine());
        }
        Console.WriteLine("Enter elements of array 2");
        int[] arr2 = new int[size];
        for (int i = 0; i < size; i++)
        {
            arr2[i] = Convert.ToInt32(Console.ReadLine());
        }

        if (arr[0] == arr2[0] || arr[size-1] == arr2[size-1])
        {
            Console.WriteLine("first or the last element of the two arrays are equal ​");
        }
        else
        {
            Console.WriteLine("first or the last element of the two arrays are equal are not equal");
        }
    }
}