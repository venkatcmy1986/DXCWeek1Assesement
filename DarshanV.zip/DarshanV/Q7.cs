class Person
{
    protected string name;
    protected string address;
    protected string phone;

    public Person(string name, string address, string phone)
    {
        this.name = name;
        this.address = address;
        this.phone = phone;
    }

    public virtual void DisplayDetails()
    {
        Console.WriteLine("Name: " + name);
        Console.WriteLine("Address: " + address);
        Console.WriteLine("Phone: " + phone);
    }
}

class Student : Person
{
    private int rollNumber;
    private string course;
    private int marks;
    private string collegeAddress;

    public Student(string name, string address, string phone, int rollNumber, string course, int marks, string collegeAddress)
        : base(name, address, phone)
    {
        this.rollNumber = rollNumber;
        this.course = course;
        this.marks = marks;
        this.collegeAddress = collegeAddress;
    }

    public override void DisplayDetails()
    {
        base.DisplayDetails();
        Console.WriteLine("Roll Number: " + rollNumber);
        Console.WriteLine("Course: " + course);
        Console.WriteLine("Marks: " + marks);
        Console.WriteLine("College Address: " + collegeAddress);
    }
}
class Program
{
    static void Main(string[] args)
    {
        Student student = new Student("Darshan", "NewYork", "1234", 512, "CSE", 99, "Baglur");
        Console.WriteLine("Student Details:");
        student.DisplayDetails();
    }
}