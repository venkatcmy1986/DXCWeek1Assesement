﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace car
{
    public interface IVehicle
    {
        int Doors { get; set; }
        int Wheels { get; set; }
        string Brand { get; set; }
        double Price { get; set; }

        void DisplayDetails();
    }

    public class Car : IVehicle
    {
        private int _doors;
        private int _wheels;
        private string _brand;
        private double _price;

        public Car(int doors, int wheels, string brand, double price)
        {
            _doors = doors;
            _wheels = wheels;
            _brand = brand;
            _price = price;
        }

        public int Doors
        {
            get { return _doors; }
            set { _doors = value; }
        }

        public int Wheels
        {
            get { return _wheels; }
            set { _wheels = value; }
        }

        public string Brand
        {
            get { return _brand; }
            set { _brand = value; }
        }

        public double Price
        {
            get { return _price; }
            set { _price = value; }
        }

        public void DisplayDetails()
        {
            Console.WriteLine("Doors: {0}", _doors);
            Console.WriteLine("Wheels: {0}", _wheels);
            Console.WriteLine("Brand: {0}", _brand);
            Console.WriteLine("Price: {0}", _price);
        }
    }

    public class Bike : IVehicle
    {
        private int _wheels;
        private string _brand;
        private double _price;
        private int _doors;

        public Bike(int doors, int wheels, string brand, double price)
        {
            _wheels = wheels;
            _brand = brand;
            _price = price;
        }

        public int Wheels
        {
            get { return _wheels; }
            set { _wheels = value; }
        }

        public string Brand
        {
            get { return _brand; }
            set { _brand = value; }
        }

        public double Price
        {
            get { return _price; }
            set { _price = value; }
        }
        public int Doors
        {
            get { return _doors; }
            set { _doors = value; }
        }

        public void DisplayDetails()
        {
            Console.WriteLine("Wheels: {0}", _wheels);
            Console.WriteLine("Brand: {0}", _brand);
            Console.WriteLine("Price: {0}", _price);
        }
    }


    class Program
    {
        static void Main(String[] args)
        {
            Car obj1 = new Car(2, 4, "skoda", 3400000);
            Bike obj2 = new Bike(0, 2, "ktm", 400000);
            obj1.DisplayDetails();
            obj2.DisplayDetails();
            Console.ReadKey();
        }

    }
}