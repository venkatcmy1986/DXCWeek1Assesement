﻿using System;
namespace inputfile
{


    public class FileOps
    {
        public static void Main(string[] args)
        {
            string fpath = @"""C:\Users\raghu\Desktop\Raghavedra DXC assessment\Welcome.txt""";
            try
            {
                if (File.Exists(fpath))
                {
                    using TextReader tr = File.OpenText(fpath);
                    Console.WriteLine(tr.ReadToEnd());
                }
                else
                {
                    FileStream fs = new FileStream(fpath, FileMode.Create);
                    using (StreamWriter sw = new StreamWriter(fs))
                        sw.WriteLine("\r\nWelcome to the world of DXC​");
                    using TextReader tr = File.OpenText(fpath);
                    Console.WriteLine(tr.ReadToEnd());

                }
            }
            catch (Exception e) 
            {
                Console.WriteLine(e.Message);
            }

        }
    }
}