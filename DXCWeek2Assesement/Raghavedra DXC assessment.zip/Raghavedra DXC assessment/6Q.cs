﻿using system;
namespace citycount
{


    class Program
    {
        static void Main()
        {
            ArrayList cities = new ArrayList();
            Console.WriteLine("Enter 10 city names:");
            for (int i = 0; i<10; i++)
            {
                cities.Add(Console.ReadLine());
            }

            Console.WriteLine("Cities starting with 'C':");
            foreach (string city in cities)
            {
                if (city.StartsWith("C") || city.StartsWith("c"))
                {
                    Console.WriteLine(city);
                }
            }
        }
    }
}
