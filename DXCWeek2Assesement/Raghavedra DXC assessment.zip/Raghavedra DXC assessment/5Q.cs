﻿using System;
using System.Collections;

class sample
{


    public static void Main()
    {


        ArrayList mylist = new ArrayList();
        Boolean flag = true;
        while (flag!=false)
        {
            Console.WriteLine("enter movie?y/n");
            char c = Console.ReadLine()[0];
            if (c == 'y')
            {
                Console.WriteLine("enter movie name");
                String name = Console.ReadLine();
                mylist.Add(name);
            }
            else
                flag = false;
        }



        Console.WriteLine("ArrayList before sort:");
        foreach (string i in mylist)
        {
            Console.WriteLine(i);
        }
        Console.WriteLine();


        Console.WriteLine("ArrayList after sort:");


        mylist.Sort();


        foreach (string i in mylist)
        {
            Console.WriteLine(i);
        }
    }
}