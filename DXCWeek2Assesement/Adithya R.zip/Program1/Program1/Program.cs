﻿class Program
{
    public static void count(int[] arr)
    {
        int even = 0;
        int odd = 0;
        foreach (int i in arr)
        {
            if(i%2 == 0)
            {
                even += 1;
            }
            else
            {
                odd += 1;
            }
        }

        Console.WriteLine("count of even numbers are "+even);
        Console.WriteLine("count of odd numbers are " + odd);

    }

    public static void Main(string[] args)
    {
        Console.WriteLine("Enter 5 numbers");
        int[] arr = new int[5];
        for(int i = 0; i < 5; i++)
        {
            arr[i] = (int)Convert.ToInt32(Console.ReadLine());
        }
        count(arr);
    }
}