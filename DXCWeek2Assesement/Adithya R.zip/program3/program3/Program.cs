﻿class Program
{
    static void Main(string[] args)
    {
        string fpath = @"D:\welcome.txt";
       
        if (File.Exists(fpath))
        {
            File.Delete(fpath);
        }
       
        FileStream fs = new FileStream(fpath, FileMode.Create);
        using (StreamWriter sw = new StreamWriter(fs))
        {
            sw.WriteLine("Welcome to the world of DXC​");
        }

        Console.WriteLine("Message in welcome file.txt is");


        try
        {
            using (StreamReader sr = new StreamReader(fpath))
            {
                string txt;
                while ((txt = sr.ReadLine()) != null)
                {
                    Console.WriteLine(txt);
                }
            }
        }
        catch (FileNotFoundException e)
        {
            Console.WriteLine(e.Message);
        }

    }
}