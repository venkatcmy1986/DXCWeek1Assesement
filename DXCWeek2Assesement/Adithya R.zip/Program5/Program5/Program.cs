﻿using System.Collections;

class Program
{
    public static void Main(string[] args)
    {
        ArrayList movie = new ArrayList();
        Console.WriteLine("Enter 10 movie names\n");
        for(int i = 0; i < 10; i++)
        {
            movie.Add(Console.ReadLine());
        }

        movie.Sort();
        movie.Reverse();

        Console.WriteLine("\n10 movie names in decending order\n");

        foreach (var item in movie)
        {
            Console.WriteLine(item);
        }



    }
}