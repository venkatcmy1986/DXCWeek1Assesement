﻿class Program
{
    public class student
    {
        public int id { get; set; }
        public string name { get; set; }
        public int english { get; set; }
        public int math { get; set; }
        public int science { get; set; }
    }

    public static void total(int a,int b,int c)
    {
        Console.WriteLine("total is "+(a+b+c));

    }
    public static void percent(int a,int b,int c)
    {
        double x = (a + b + c) ;
        Console.WriteLine("percent is " + (x/300)*100);

    }
    public static void Main(string[] args)
    {
        student s1 = new student();
        Console.WriteLine("enter student name");
        s1.name = Console.ReadLine();

        Console.WriteLine("enter student id (integer) ");
        s1.id = (int)Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("enter student mark in english out of 100");
        s1.english = (int)Convert.ToInt32(Console.ReadLine()); 

        Console.WriteLine("enter student mark in maths out of 100");
        s1.math = (int)Convert.ToInt32(Console.ReadLine()); 

        Console.WriteLine("enter student mark in science out of 100");
        s1.science = (int)Convert.ToInt32(Console.ReadLine());


        Console.WriteLine("\n\nstudent details are");
        Console.WriteLine($"name {s1.name} id {s1.id}");
        total(s1.english, s1.science, s1.math);
        percent(s1.english, s1.science, s1.math);

    }
}