﻿using System.Transactions;

public interface IVehicle
{
    public int door { get; set; }
    public int wheels { get; set; }
    public string brand { get; set; }
    public int price { get; set; }
    public void displaydetails();
}
class bike : IVehicle
{
    public int door { get; set; }
    public int wheels { get; set; }
    public string brand { get; set; }
    public int price { get; set; }
    public void displaydetails()
    {
        Console.WriteLine("bike details are");
        Console.WriteLine($"doors {door} wheels {wheels} brand {brand} price {price}\n\n");
    }
}
class car : IVehicle
{
    public int door {get; set; }
    public int wheels { get; set; }
    public string brand { get; set; }
    public int price { get; set; }
    public void displaydetails()
    {
        Console.WriteLine("car details are");
        Console.WriteLine($"doors {door} wheels {wheels} brand {brand} price {price}\n\n");
    }

    public static void Main(string[] args)
    {
        car c = new car();
        Console.WriteLine("enter car details \nno of door \nno of wheel\nbrand name\nprice of can");
        c.door = (int)Convert.ToInt32(Console.ReadLine());
        c.wheels = (int)Convert.ToInt32(Console.ReadLine());
        c.brand = Console.ReadLine();
        c.price = (int)Convert.ToInt32(Console.ReadLine());

        c.displaydetails();



        bike b = new bike();
        Console.WriteLine("\n\n\nenter bike details \nno of door \nno of wheel\nbrand name\nprice of car");
        b.door = (int)Convert.ToInt32(Console.ReadLine());
        b.wheels = (int)Convert.ToInt32(Console.ReadLine());
        b.brand = Console.ReadLine();
        b.price = (int)Convert.ToInt32(Console.ReadLine());

        b.displaydetails();
    }

}