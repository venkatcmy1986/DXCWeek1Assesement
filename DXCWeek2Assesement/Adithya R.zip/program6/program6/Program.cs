﻿using System.Collections.Generic;
class Program
{
    public static void Main(string[] args)
    {
        List<string> list = new List<string>();

        Console.WriteLine("enter 10 city names");
        for(int i = 0; i < 10; i++)
        {
            list.Add(Console.ReadLine());
        }
        Console.WriteLine("\n\ncities which start with c");

        foreach (var item in list)
        {
            if (item.StartsWith('c'))
            {
                Console.WriteLine(item);
            }
        }

    }
}