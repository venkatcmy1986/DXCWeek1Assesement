﻿//1. Write a C# Program that takes a number and a width . It then displays a triangle of that width using the number.

using System;

public class Triangle
{
    public static void Main(string[] args)
    {
        int num = 5;
        int wid = 5;
        int hei = wid;

        for (int i = 0; i < hei; i++)
        {
            for (int j = 0; j < wid; j++)
            {
                Console.Write(num);
            }
            Console.WriteLine();
            wid--;
        }

        Console.ReadKey();
    }
}
