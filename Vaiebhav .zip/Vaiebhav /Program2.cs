﻿// Write a C# Program to check if the first or the last element of the two arrays(Length 1 or more) are equal

using System;

public class CheckEquality
{
    public static void Main(string[] args)
    {
        int[] array1 = { 1, 2, 3 };
        int[] array2 = { 4, 5, 6 };

        if (array1[0] == array2[0])
        {
            Console.WriteLine("First Elements are equal");
        }
        else
        {
            Console.WriteLine("First Elements are not equal");
        }

        if (array1[array1.Length - 1] == array2[array2.Length - 1])
        {
            Console.WriteLine("Last Elements are equal");
        }
        else
        {
            Console.WriteLine("Last Elements are not equal");
        }

        Console.ReadKey();
    }
}
