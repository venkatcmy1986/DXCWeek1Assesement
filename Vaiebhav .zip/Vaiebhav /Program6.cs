﻿//Create a class called Vehicle with brand, color, price, year of manufacturing as attributes. //Provide appropriate constructors, functions. Write Main() in a separate class  class Vehicle
{
    public string brand, color;
    public int price, year;
    public Vehicle(String b, String c, int p, int y)
    {
        brand = b;
        color = c;
        price = p;
        year = y;
    }
    public void getDetails()
    {
        Console.WriteLine("Brand: {0}\n", brand);
        Console.WriteLine("Color: {0}\n", color);
        Console.WriteLine("Price: {0}\n", price);
        Console.WriteLine("Year: {0}\n", year);
    }
}

class Program6
{
    static void Main(string[] args)
    {
        Vehicle v = new Vehicle("Lamborgini", "Green", 10000000, 2001);
        v.getDetails();

        Console.ReadKey();
    }
}