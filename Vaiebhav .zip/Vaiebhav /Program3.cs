﻿//Write a C# Sharp program to determine the eligibility for admission to a professional course based on the following criteria:
//Marks in Maths >=65
//Marks in Physics >=55
//Marks in Chemistry >=50
//Total in all three subject >= 180 or
//Total in Math and Physics >= 140


using System;

public class Eligibility
{
    public static void Main(string[] args)
    {
        int math = Convert.ToInt32(Console.ReadLine());
        int phys = Convert.ToInt32(Console.ReadLine());
        int chem = Convert.ToInt32(Console.ReadLine());

        if ((math >= 65 && phys >= 55 && chem >= 50) || (math + phys >= 140) || (math + phys + chem >= 180))
        {
            Console.WriteLine("The candidate is eligible");
        }
        else
        {
            Console.WriteLine("The candidate is not eligible");
        }

        Console.ReadKey();
    }
}
