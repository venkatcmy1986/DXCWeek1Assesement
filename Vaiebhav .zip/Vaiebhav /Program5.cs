﻿using System;

class Stack
{
    private int[] array;
    private int top;
    private int capacity;

    public Stack(int size)
    {
        capacity = size;
        array = new int[capacity];
        top = -1;
    }

    public bool IsEmpty()
    {
        return top == -1;
    }

    public bool IsFull()
    {
        return top == capacity - 1;
    }

    public void Push(int val)
    {
        array[++top] = val;
        Console.WriteLine("Pushed element: " + val);
    }

    public int Pop()
    {
        int val = array[top--];
        Console.WriteLine("Popped element: " + val);
        return val;
    }

    public void PrintStack()
    {
        Console.WriteLine("Elements in the stack:");
        for (int i = top; i >= 0; i--)
        {
            Console.WriteLine(array[i]);
        }
    }
}

class Program
{
    static void Main()
    {
        Stack stack = new Stack(5);

        stack.Push(1);
        stack.Push(2);
        stack.Push(3);

        Console.WriteLine("Enter Element to remove");
        int target = Convert.ToInt32(Console.ReadLine());
        int ele = 0;

        while (target != ele)
        {
            ele = stack.Pop();
            stack.PrintStack();
        }

        Console.ReadKey();
    }
}
