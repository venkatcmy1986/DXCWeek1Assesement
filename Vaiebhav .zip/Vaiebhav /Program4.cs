﻿//Program to generate Fibonacci Triangle

using System;

public class FibonacciTriangle
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter no. of Rows in Triangle");
        int rows = Convert.ToInt32(Console.ReadLine());

        int[] fibo = new int[rows];
        fibo[0] = 0;
        fibo[1] = 1;

        for (int i = 2; i < rows; i++)
        {
            fibo[i] = fibo[i - 1] + fibo[i - 2];
        }

        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j <= i; j++)
            {
                Console.Write("{0}", fibo[j]);
            }
            Console.WriteLine();
        }

        Console.ReadKey();
    }
}
