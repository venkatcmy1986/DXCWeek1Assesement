﻿class problem2
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter array size 1");
        int a=(int) Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter array size 2");
        int b = (int)Convert.ToInt32(Console.ReadLine());
        int[] arr1=new int[a];
        int[] arr2=new int[b];


        Console.WriteLine("enter array1 elements");
        for(int i=0; i<arr1.Length; i++)
        {
            arr1[i]=(int) Convert.ToInt32(Console.ReadLine());
        }


        Console.WriteLine("enter array2 elements");
        for (int i = 0; i < arr2.Length; i++)
        {
            arr2[i] = (int)Convert.ToInt32(Console.ReadLine());
        }

        if (arr1[0] == arr2[0] || arr1[a - 1] == arr2[b-1])
        {
            Console.WriteLine("is equal");
        }
        else
        {
            Console.WriteLine("not equal");
        }
    }
}