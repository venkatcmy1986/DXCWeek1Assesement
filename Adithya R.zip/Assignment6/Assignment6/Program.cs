﻿class Vehicle
{
    public string brand;
    public string color;
    public int price;
    public int year;
    public Vehicle(string brand, string color, int price,int year)
    {
        this.brand = brand;
        this.color = color;
        this.price = price;
        this.year=year;
    }
}
class car
{
    public static void Main(string[] args)
    {
        Vehicle v = new Vehicle("ford","white",50000,2019);
        Console.WriteLine(v.brand); 
        Console.WriteLine(v.color);
        Console.WriteLine(v.price);
        Console.WriteLine(v.year);

    }
}