﻿class person
{
    string name;
    string address;
    string phoneno;
    

    public virtual void get_name()
    {
        Console.WriteLine(this.name);
    }
}
class student:person
{
    string name;
    string address;
    string phoneno;
    string rollno;
    string course;

    public student(string name, string address, string phoneno,string rollno,string course)
    {
        this.name = name;
        this.address = address;
        this.phoneno = phoneno;
        this.course = course;
        this.rollno = rollno;
    }

    public override void get_name()
    {
        Console.WriteLine("overide method");
    }

    public static void Main(string[] args)
    {
        student s = new student("abc", "ashbc", "12345", "r34", "cs");
        Console.WriteLine(s.get_name);
    }
}