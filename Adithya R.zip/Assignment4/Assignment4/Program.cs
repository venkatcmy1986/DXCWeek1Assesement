﻿class program4
{
    public static void Main(string[] args)
    {
        int firstno = 0;
        int secondno = 1;
        int nextno;
        Console.WriteLine("Enter No of element to print");
        int n=(int) Convert.ToInt32(Console.ReadLine());
        if (n < 2)
        {
            Console.WriteLine("enter No. greater than 2");
        }
        else
        {
            Console.Write(firstno + " " + secondno+ " ");
            for(int i = 2; i < n; i++)
            {
                nextno = firstno + secondno;
                Console.Write(nextno + " ");
                firstno = secondno;
                secondno = nextno;
            }
        }
    }
}
