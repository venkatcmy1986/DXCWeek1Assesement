﻿class problem3
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter markas in math, physics and chemistry");
        int math=(int) Convert.ToInt32(Console.ReadLine());
        int phy=(int) Convert.ToInt32(Console.ReadLine());
        int chem=(int) Convert.ToInt32(Console.ReadLine());
        if (math >= 65)
            if (phy >= 55)
                if (chem >= 50)
                    if ((math + phy + chem) >= 180 || (math + phy) >= 140 || (math + chem) >= 140)
                        Console.Write("The  candidate is eligible for admission.\n");
                    else
                        Console.Write("The candidate is not eligible.\n\n");
                else
                    Console.Write("The candidate is not eligible.\n\n");
            else
                Console.Write("The candidate is not eligible.\n\n");
        else
            Console.Write("The candidate is not eligible.\n\n");
    }
}
