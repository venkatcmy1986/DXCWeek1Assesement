﻿public class Stack
{
    private int[] items;
    private int top;

    public Stack(int size)
    {
        items = new int[size];
        top = -1;
    }

    public bool IsEmpty()
    {
        return top == -1;
    }

    public bool IsFull()
    {
        return top == items.Length - 1;
    }

    public void Push(int item)
    {
        if (IsFull())
        {
            Console.WriteLine("Stack Full");
            return;
        }

        items[++top] = item;
    }

    public int Pop()
    {
        if (IsEmpty())
        {
            Console.WriteLine("underflow");
            return -1;
        }

        return items[top--];
    }

    public int Peek()
    {
        if (IsEmpty())
        {
            Console.WriteLine("empty");
            return -1;
        }

        return items[top];
    }

    public static int Size(Stack stack)
    {
        return stack.top + 1;
    }

    // Method to remove an element
    public static void remove_an_element(Stack stack, int value)
    {
        Stack temp = new Stack(Size(stack));

        while (!stack.IsEmpty())
        {
            int element = stack.Pop();

            if (element != value)
            {
                temp.Push(element);
            }
        }

        while (!temp.IsEmpty())
        {
            stack.Push(temp.Pop());
        }
    }
    public static void Display(Stack stack)
    {
        if (stack.IsEmpty())
        {
            Console.WriteLine("Stack is empty");
            return;
        }

        Console.WriteLine("Stack elements:");
        for (int i = stack.top; i >= 0; i--)
        {
            Console.Write(stack.items[i] + " ");
        }
    }
}
public class Program
{
    public static void Main(string[] args)
    {
        Stack stack = new Stack(5);
        stack.Push(1);
        stack.Push(2);
        stack.Push(3);
        stack.Push(4);
        stack.Push(5);
        Stack.Display(stack);
        Console.WriteLine("\n\nRemove 2");
        Stack.remove_an_element(stack, 2);
        Stack.Display(stack);
    }
}