﻿
//question 1
public class assignment1
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter a number ");
        int num=(int)Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Enter width ");
        int width=(int)Convert.ToInt32(Console.ReadLine());

        for(int i = 1; i <= width; i++)
        {
            for(int j=1; j <= width-i; j++)
            {
                Console.Write(" ");
            }
            for(int k=1; k <= i; k++)
            {
                Console.Write(num);
            }
            Console.WriteLine("");
        }
        Console.ReadLine();
    }
}