﻿using System.Collections;

class Program
{
    public static void Main()
    {

        ArrayList arr = new ArrayList();
        bool flag = true;
        while (flag != false)
        {
            Console.WriteLine("enter movie? y/n");
            char c = Console.ReadLine()[0];
            if (c == 'y')
            {
                Console.WriteLine("enter movie name");
                string name = Console.ReadLine();
                arr.Add(name);
            }
            else
                flag = false;
        }

        Console.WriteLine("ArrayList before sorting:");
        foreach (string i in arr)
        {
            Console.WriteLine(i);
        }
        Console.WriteLine();


        Console.WriteLine("ArrayList in descending order:");

        arr.Sort();
        arr.Reverse();

        foreach (string i in arr)
        {
            Console.WriteLine(i);
        }
    }
}