﻿interface IVehicle
{
    public void displaydetails();
    public string getDoor();
    public string getWheels();
    public int getPrice();
    public string getBrand();

}

class Car : IVehicle
{
    public string door;
    public string wheels;

    public string brand;
    public int price;


    public Car(string door, string wheels, string brand, int price)
    {
        this.door = door;
        this.wheels = wheels;
        this.brand = brand;
        this.price = price;
    }

    public void displaydetails()
    {
        Console.WriteLine("The detials of car are");
        Console.WriteLine(this.door);
        Console.WriteLine(this.wheels);
        Console.WriteLine(this.brand);
        Console.WriteLine(this.price);
    }

    public string getDoor()
    {
        return this.door;

    }
    public string getWheels()
    {
        return this.wheels;
    }
    public int getPrice()
    {
        return this.price;
    }
    public string getBrand()
    {
        return this.brand;
    }


}


class Bike : IVehicle
{
    public string door;
    public string wheels;
    public string brand;
    public int price;

    public Bike(string wheels, string brand, int price)
    {
        door = "Not Available";
        this.wheels = wheels;
        this.brand = brand;
        this.price = price;
    }

    public void displaydetails()
    {
        Console.WriteLine("The detials of bike are");
        Console.WriteLine(this.door);
        Console.WriteLine(this.wheels);
        Console.WriteLine(this.brand);
        Console.WriteLine(this.price);
    }
    public string getDoor()
    {
        return this.door;

    }
    public string getWheels()
    {
        return this.wheels;
    }
    public int getPrice()
    {
        return this.price;
    }
    public string getBrand()
    {
        return this.brand;
    }

}

class Program
{
    public static void Main(string[] args)
    {
        Car c = new Car("Aluminium", "Alloy wheels", "Hyundai", 1000000);
        Bike b = new Bike("Split Rim wheels", "Hero", 85000);

        b.displaydetails();
        c.displaydetails();

    }
}