﻿using System.Collections;

class Program
{
    static void Main()
    {
        List<string> arr = new List<string>();
        Console.WriteLine("Enter 10 city names:");
        for (int i = 0; i < 10; i++)
        {
            arr.Add(Console.ReadLine());
        }

        Console.WriteLine("Cities starting with 'C':");
        foreach (string city in arr)
        {
            if (city.StartsWith("C") || city.StartsWith("c"))
            {
                Console.WriteLine(city);
            }
        }
    }
}