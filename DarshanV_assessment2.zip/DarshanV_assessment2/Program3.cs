﻿public class FileOps
{
    public static void Main(string[] args)
    {
        string fpath = @"E:\College_dox\DXC\DXCAssessment week 2\question3\welcome.txt";
        try
        {
            if (File.Exists(fpath))
            {
                using TextReader tr = File.OpenText(fpath);
                Console.WriteLine(tr.ReadToEnd());
            }
            else
            {
                FileStream fs = new FileStream(fpath, FileMode.Create);
                using (StreamWriter sw = new StreamWriter(fs))
                    sw.WriteLine("\r\nWelcome to the world of DXC​");

                using TextReader tr = File.OpenText(fpath);
                Console.WriteLine(tr.ReadToEnd());

            }
        }
        catch (Exception e) // catch error if path permission is denied
        {
            Console.WriteLine(e.Message);
        }

    }

}