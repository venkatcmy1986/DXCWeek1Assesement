﻿using System;
using System.Collections;
class program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter 5 numbers");
        int[] arr = new int[5];
        for (int i = 0;i<5;i++)
        {
            arr [i] = Convert.ToInt32(Console.ReadLine());
        }
        int eve_count = 0;
        int odd_count = 0;
        foreach (int item in arr)
        {
            if(item%2 ==0) eve_count ++;
            else odd_count ++;

        }
        Console.WriteLine("even Number count "+ eve_count);
        Console.WriteLine("Odd number count "+ odd_count);
    }
}