﻿public class StudentInfo
{
    private int rollNo;
    private string studName;
    private int engMarks;
    private int mathMarks;
    private int scienceMarks;

    public StudentInfo(int rollNo, string studName, int engMarks, int mathMarks, int scienceMarks)
    {
        this.rollNo = rollNo;
        this.studName = studName;
        this.engMarks = engMarks;
        this.mathMarks = mathMarks;
        this.scienceMarks = scienceMarks;
    }

    public int GetTotalMarks()
    {
        return engMarks + mathMarks + scienceMarks;
    }

    public float GetPercentage()
    {
        float totalMarks = engMarks + mathMarks + scienceMarks;
        float percentage = (totalMarks / 300) * 100;
        return percentage;
    }

    public void DisplayDetails()
    {
        Console.WriteLine("Roll No: {0}", rollNo);
        Console.WriteLine("Stud Name: {0}", studName);
        Console.WriteLine("Eng Marks: {0}", engMarks);
        Console.WriteLine("Math Marks: {0}", mathMarks);
        Console.WriteLine("Science Marks: {0}", scienceMarks);
        Console.WriteLine("Total Marks: {0}", GetTotalMarks());
        Console.WriteLine("Percentage: {0:0.00}", GetPercentage());
    }
}

class Program
{
    static void Main(string[] args)
    {
        int studNo, engMarks, mathMarks, scienceMarks;
        String name;
        Console.WriteLine("enter roll number");
        studNo = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("enter Name");
        name = Console.ReadLine();
        Console.WriteLine("enter english marks");
        engMarks = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("enter math marks");
        mathMarks = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("enter science marks");
        scienceMarks = Convert.ToInt32(Console.ReadLine());

        StudentInfo s = new StudentInfo(studNo, name, engMarks, mathMarks, scienceMarks);
        s.DisplayDetails();

    }
}
