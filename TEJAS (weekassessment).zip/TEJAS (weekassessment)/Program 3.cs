﻿using System;

namespace Progm
{
    public class Program
    {
        static void Main(string[] args)
        {

            string temp = string.Empty;
            int[] numbers = new int[3];



            for (int i = 0;; )
            {
                Console.WriteLine("Please enter the " + "Maths Physics Chemistry".Split()[i] + " score.");

                if (string.IsNullOrEmpty(temp = Console.ReadLine()))
                {
                    Console.WriteLine("please enter a numeric value.");
                }
                else
                {
                    if (int.TryParse(temp, out numbers[i]))
                    { 
                        if (i == 2)
                            break;
                    
                        i++;
                    }
                    else
                    {
                        Console.WriteLine("BAD INPUT: you must enter a numeric value.");
                    }
                }
            }

            int maths = numbers[0];
            int phy = numbers[1];
            int chem = numbers[2];

            string output = $"Maths: {maths}" + $"Physics: {phy}" + $"Chemistry: {chem}" + $"Total: {maths + phy + chem}" + $"Maths + Physics total: {maths + phy}" ;

            if (maths >= 65 && phy >= 55 && chem >= 50 && ((maths + phy + chem) >= 180 || (maths + phy) >= 140))
            {
                output += $"The candidate is eligible for enrollment.";
            }
            else
            {
                output += "The candidate is not eligible for enrollment.";
            }

            Console.WriteLine(output);
            Console.ReadLine();

        }
    }
}