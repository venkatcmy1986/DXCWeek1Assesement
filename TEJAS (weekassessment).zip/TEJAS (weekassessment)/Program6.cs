﻿using System;
namespace sample
{

    class Car
    {

        public String brand;
        public String color;
        public int price;
        int Year_of_manifacture;
        public Car()
        {
            brand = "KIA";
            color = "White";
            price = 1000000;
        }
    }

    class vehicle
    {
        public static void Main(String[] args)
        {
            Car obj = new Car();
            Console.WriteLine(obj.brand);
            Console.WriteLine(obj.color);
            Console.WriteLine(obj.price);
       
        }

    }
}