﻿using System;
using System.Collections.Generic;

class prg
{

    // Main Method
    public static void Main()
    {

        // Creating a Stack of integers
        Stack<int> myStack = new Stack<int>();

        // Inserting the elements into the Stack
        myStack.Push(7);
        myStack.Push(9);

        Console.WriteLine("Number of elements in the Stack: {0}",
                                                  myStack.Count);

        // Retrieveing top element of Stack
        Console.Write("Top element of Stack is: ");
        Console.Write(myStack.Pop());

        // printing the no of Stack element
        // after Pop operation
        Console.WriteLine("\nNumber of elements in the Stack: {0}",
                                                    myStack.Count);
    }
}