﻿using System;
namespace TestSample
{

    class MyProgram
    {
        static void Main(string[] args)
        {

            Console.WriteLine("enter the size of 1st and 2nd array");
            int size1 = Convert.ToInt32(Console.ReadLine());
            int size2 = Convert.ToInt32(Console.ReadLine());
            int[] a = new int[size1];
            int[] b = new int[size2];
            Console.WriteLine("enter the elements of 1st array");
            for (int i = 0; i < size1; i++)
            {
               a[i] == Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("enter the elements of 2nd array");
            for (int i = 0; i < size2; i++)
            {
               b[i] == Convert.ToInt32(Console.ReadLine());
            }


            if (a[0] == b[0] || a[size1 - 1] == b[size2 - 1])
            {
                Console.WriteLine("First or last elemts are equal");
            }



        }

    }
}