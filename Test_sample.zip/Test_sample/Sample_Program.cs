using System;
class Person
{
    protected string name;

    public Person(string name)
    {
        this.name = name;
    }

    public void DisplayDetails()
    {
        Console.WriteLine("Name: " + name);
    }
}
class Student : Person
{
    private int rollNumber;

    public Student(string name, int rollNumber) : base(name)
    {
        this.rollNumber = rollNumber;
    }

    public void DisplayRollNumber()
    {
        Console.WriteLine("Roll Number: " + rollNumber);
    }
}
class CollegeStudent : Student
{
    private string collegeName;

    public CollegeStudent(string name, int rollNumber, string collegeName) : base(name, rollNumber)
    {
        this.collegeName = collegeName;
    }

    public void DisplayCollegeName()
    {
        Console.WriteLine("College Name: " + collegeName);
    }
}
//interface
interface FirstInterface
{
    void Python(); 
}

interface SecondInterface
{
    void Java(); 
}

interface ThirdInterface
{
    void CSharp();
}
class Subjects : FirstInterface, SecondInterface , ThirdInterface //multiple interface
{
    public void Python()
    {
        Console.WriteLine("\n Here I have used Multiple Interfaces");
        Console.WriteLine("can build model in ML,NLP");
    }
    public void Java()
    {
        Console.WriteLine("can build basic apps in android studio");
    }
    public void CSharp()
    {
        Console.WriteLine("Learning C# in visual studio to work with .Net framework ");
        Console.WriteLine("\nAre you enjoyng coding using C# ?");
        string Feedback = Convert.ToString(Console.ReadLine());
    }
}
class Program
{
    static void Main(string[] args)
    {
        CollegeStudent student = new CollegeStudent("Shraddha KB",123, "Reva University");

        student.DisplayDetails();
        student.DisplayRollNumber();
        student.DisplayCollegeName();

        double sem, result;
        char selectedSem;
        char continueChoice;
        bool continueSem = true;

        Subjects myObj = new Subjects();//interface code
        myObj.Python();
        myObj.Java();
        myObj.CSharp();

        while (continueSem)
        {
            Console.Write("\nSelect the semester to know your CGPA: ");
            

            Console.Write("Choose the Semester  (1 2 3 4 5 6 7 8): ");
            selectedSem = Console.ReadLine()[0];

            switch (selectedSem)
            {
                case '1':
                    result = 9.1;
                    Console.WriteLine("Result: " + result);
                    break;
                case '2':
                    result = 9.3;
                    Console.WriteLine("Result: " + result);
                    break;
                case '3':
                    result = 9;
                    Console.WriteLine("Result: " + result);
                    break;
                case '4':
                    result = 9.5;
                    Console.WriteLine("Result: " + result);
                    break;
                case '5':
                    result = 9.45;
                    Console.WriteLine("Result: " + result);
                    break;
                case '6':
                    result = 9.23;
                    Console.WriteLine("Result: " + result);
                    break;
                case '7':
                    result = 8.9;
                    Console.WriteLine("Result: " + result);
                    break;
                case '8':
                    result = 9;
                    Console.WriteLine("Result: " + result);
                    break;

                default:
                    Console.WriteLine("Error: Invalid Semester.");
                    break;
            }

            Console.WriteLine();

            Console.Write("Do you want to continue (Y/N)? ");
            continueChoice = Console.ReadLine()[0];
            continueSem = (continueChoice == 'Y' || continueChoice == 'y');
        }

        Console.WriteLine("Program finished.");
    }
}