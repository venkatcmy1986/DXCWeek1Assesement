//program 1
using System;

class TriWidth
{
    static void Main(string[] args)
    {
        Console.Write("enter number: ");
        int number = Convert.ToInt32(Console.ReadLine());

        Console.Write("enter width: ");
        int width = Convert.ToInt32(Console.ReadLine());

        DisplayTriangle(number, width);
    }

    static void DisplayTriangle(int number, int width)
    {
        for (int i = 1; i <= width; i++)
        {
            for (int j = 1; j <= i; j++)
            {
                Console.Write(number + " ");
            }

            Console.WriteLine();
        }
    }
}