//program 4 fibonaci triangle
using System;

class fibonaci
{
    static void Main(string[] args)
    {
        Console.WriteLine("How many rows for fibonaci triangle: ");
        int rows = Convert.ToInt32(Console.ReadLine());

        GenerateFibonaciTriangle(rows);
    }

    static void GenerateFibonaciTriangle(int rows)
    {
        int a = 0, b = 1, c;

        for (int i = 1; i <= rows; i++)
        {
            for (int j = 1; j <= i; j++)
            {
                Console.Write(a + " ");

                c = a + b;
                a = b;
                b = c;
            }

            Console.WriteLine();
        }
    }
}