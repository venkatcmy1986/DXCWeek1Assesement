//program 5
using System;
using System.Collections.Generic;

class Program5
{
    static void Main(string[] args)
    {
        
        Stack<int> stack = new Stack<int>();
        stack.Push(1);
        stack.Push(2);
        stack.Push(3);
        stack.Push(4);
        stack.Push(5);

        Console.WriteLine("Original Stack:");
        PrintStack(stack);

        int elementToRemove = 5;
        RemoveFromStack(stack, elementToRemove);

        Console.WriteLine("Modified Stack:");
        PrintStack(stack);
    }

    static void RemoveFromStack(Stack<int> stack, int element)
    {
        Stack<int> tempStack = new Stack<int>();

        while (stack.Count > 0)
        {
            int currentElement = stack.Pop();

            if (currentElement != element)
            {
                tempStack.Push(currentElement);
            }
        }

        while (tempStack.Count > 0)
        {
            stack.Push(tempStack.Pop());
        }
    }

    static void PrintStack(Stack<int> stack)
    {
        foreach (int element in stack)
        {
            Console.WriteLine(element);
        }
    }
}