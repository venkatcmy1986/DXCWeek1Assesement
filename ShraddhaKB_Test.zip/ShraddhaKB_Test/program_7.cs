//program 7
using System;

class Person
{
    public string Name { get; set; }
    public string Address { get; set; }
    public string Phone { get; set; }

    public Person(string name, string address, string phone)
    {
        Name = name;
        Address = address;
        Phone = phone;
    }

    public virtual void DisplayDetails()
    {
        Console.WriteLine("Person Details:");
        Console.WriteLine("Name: " + Name);
        Console.WriteLine("Address: " + Address);
        Console.WriteLine("Phone: " + Phone);
    }
}

class Student : Person
{
    public int RollNumber { get; set; }
    public string Course { get; set; }
    public int Marks { get; set; }
    public string CollegeAddress { get; set; }

    public Student(string name, string address, string phone, int rollNumber, string course, int marks, string collegeAddress)
        : base(name, address, phone)
    {
        RollNumber = rollNumber;
        Course = course;
        Marks = marks;
        CollegeAddress = collegeAddress;
    }

    public override void DisplayDetails()
    {
        base.DisplayDetails();
        Console.WriteLine("Roll Number: " + RollNumber);
        Console.WriteLine("Course: " + Course);
        Console.WriteLine("Marks: " + Marks);
        Console.WriteLine("College Address: " + CollegeAddress);
    }
}

class Program
{
    static void Main(string[] args)
    {
        Person person = new Person("Shraddha KB", "Godrej Avenues ", "7019136759");
        person.DisplayDetails();
        Console.WriteLine();

        Student student = new Student("Shraddha kb", "Godrej Avenues", "7019136759", 093, "CSIT", 95, "Reva College");
        student.DisplayDetails();
    }
}