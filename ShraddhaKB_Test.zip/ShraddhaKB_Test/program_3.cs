//Program 3
using System;
class Admission
{
    static void Main(string[] args)
    {
        Console.WriteLine("Enter Math marks");
        int mathm=Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter Phy marks");
        int Phym = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter Chemm marks");
        int Chemm = Convert.ToInt32(Console.ReadLine());

        int TotMar = mathm + Phym + Chemm;

        string eligibility = (mathm >= 65 && Phym >= 55 && Chemm >= 50 && TotMar >= 180) || (mathm >= 65 && TotMar >= 140) ? "Eligible" : "Not Eligible";
        Console.WriteLine(eligibility);
    }
}