//program 2
using System;
class Program2
{
    static void Main(string[] args)
    {
        int[] array1 = { 1, 2, 1 };
        int[] array2 = { 3, 2, 1 };

        bool result = CheckFirstOrLastElementEquality(array1, array2);

        Console.WriteLine("1st or last ele equality: " + result);
    }

    static bool CheckFirstOrLastElementEquality(int[] array1, int[] array2)
    {
        if (array1.Length >= 1 && array2.Length >= 1)
        {
            if (array1[0] == array2[0] || array1[array1.Length - 1] == array2[array2.Length - 1])
            {
                return true;
            }
        }

        return false;
    }
}